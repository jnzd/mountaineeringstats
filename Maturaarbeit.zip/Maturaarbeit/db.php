<?php
  $conn = mysqli_connect("127.0.0.1", "mounqytg_root", "vvRgI&l?Nei_", "mounqytg_mountain");
?>
