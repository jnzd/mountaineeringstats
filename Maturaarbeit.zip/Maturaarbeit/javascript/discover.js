var discover;
function initMap() {
  map = new google.maps.Map(document.getElementById('discover'), {
    center: {lat: -34.397, lng: 150.644},
    zoom: 8
  });
}