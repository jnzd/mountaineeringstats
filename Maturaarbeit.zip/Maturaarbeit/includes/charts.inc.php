<canvas class="chart" id="elevation" ></canvas>
<script src="node_modules/chart.js/dist/Chart.js"></script>
<script>
	var elevation = <?php echo $elevation_js; ?>;
	var time = <?php echo $time_js; ?>;
	var speed = <?php echo $speed_js; ?>;
</script>
<script src="javascript/chart.js"></script>
