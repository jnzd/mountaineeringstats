<div id="map"></div>
<script>
  //set javascript arrays
  var lat = <?php echo $lat_js; ?>;
  var lng = <?php echo $long_js; ?>;
</script>
<script src="javascript/map.js"></script>