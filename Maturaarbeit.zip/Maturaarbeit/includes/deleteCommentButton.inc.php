<div id="deleteComment<?php echo $commentID; ?>" class="deleteComment">
  <button class="deleteCommentButton" type="button" onclick="deleteComment(<?php echo $commentID; ?>)"></button>
</div>
<script src="javascript/deleteComment.js"></script>