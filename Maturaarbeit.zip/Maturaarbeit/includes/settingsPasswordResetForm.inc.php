<form action= "includes/settingsPasswordReset.inc.php" method="post">
  <div class="settingsBlock">
    <label class="settingsLabel" for="email">E-Mail Adresse</label>
    <input class="settingsInput" type="email" id="email" name="email" placeholder="E-Mail"><br>
  </div>
  <div class="settingsBlock">
    <label class="settingsLabel" for="reset"></label>
    <input type="submit" id="reset" name="reset" value="Passwort zurücksetzen"><br><br>
  </div>
</form>