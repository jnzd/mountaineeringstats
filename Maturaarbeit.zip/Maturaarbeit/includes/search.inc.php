<?php
	$search = $_POST['search'];
	header("location: ../search.php?search=".$search);
?>
